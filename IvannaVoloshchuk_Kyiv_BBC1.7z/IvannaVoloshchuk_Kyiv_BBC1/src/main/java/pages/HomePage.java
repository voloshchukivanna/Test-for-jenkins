package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage{

    @FindBy(xpath = "//nav[@class='orbit-header-links international']//span[text()='News']")
    private WebElement newsButton;

    @FindBy(xpath = "//a[@class='orbit-search__button']")
    private WebElement searchButton;

    public HomePage(WebDriver driver) { super(driver); }

    public void openHomePage(String url) { driver.get(url); }

    public void isNewsButtonVisible() { newsButton.isDisplayed(); }

    public void clickNewsButton() { newsButton.click(); }

    public void isSearchButtonVisible() { searchButton.isDisplayed(); }

    public void clickSearchButton() { searchButton.click(); }

}
