package pages;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;


public class NewsPage extends BasePage{

    @FindBy(xpath = "//div[contains(@class,'gs-c-promo-body gs-u-display-none ')]//p[contains(@class,'gs-c-promo-summary ')]")
    private WebElement mainArticle;

    @FindBy(xpath = "//div[@class='nw-c-5-slice gel-layout gel-layout--equal']//h3")
    private List<WebElement> subArticles;

    @FindBy(xpath = "//a[@class='orbit-search__button']")
    private WebElement searchField;

    @FindBy(xpath = "//li[contains(@class,'gs-o-list-ui__item--flush gel-long-primer ')]//span[text()='Coronavirus']")
    private WebElement coronavirusButton;

    public NewsPage(WebDriver driver) { super(driver); }

    public String mainArticleGetText(){ return mainArticle.getText(); }

    public void waitForPageLoadComplete(long timeToWait) {
        new WebDriverWait(driver, Duration.ofSeconds(timeToWait)).until(
                webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
    }

    public String subArticlesGetText(int i){ return subArticles.get(i).getText(); }

    public void isSearchFieldVisible() { searchField.isDisplayed(); }

    public void isCoronavirusButtonVisible() { coronavirusButton.isDisplayed(); }

    public void clickCoronavirusButton() { coronavirusButton.click(); }

}
