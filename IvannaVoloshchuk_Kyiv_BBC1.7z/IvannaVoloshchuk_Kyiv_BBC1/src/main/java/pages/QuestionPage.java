package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import java.util.concurrent.TimeUnit;

public class QuestionPage extends BasePage{

    @FindBy(xpath = "//input[@aria-label='Name']")
    private WebElement nameTextFieldButton;

    @FindBy(xpath = "//input[@aria-label='Email address']")
    private WebElement emailTextFieldButton;

    @FindBy(xpath = "//input[@aria-label='Contact number']")
    private WebElement phoneTextFieldButton;

    @FindBy(xpath = "//input[@aria-label='Location ']")
    private WebElement locationTextFieldButton;

    @FindBy(xpath = "//input[@aria-label='Age']")
    private WebElement ageTextFieldButton;

    @FindBy(xpath = "//input[@type='checkbox']")
    private WebElement checkBoxSelected;

    @FindBy(xpath = "//button[@aria-label='Close']")
    private WebElement closePopupButton;

    @FindBy(xpath = "//div[@class='button-container']/button[text()='Submit']")
    private WebElement submitButton;

    @FindBy(xpath = "//div[@class='long-text-input-container']//div[@class='input-error-message']")
    private WebElement errorQuestionText;

    @FindBy(xpath = "//textarea[@aria-label='What questions would you like us to answer?']")
    private WebElement questionTextField;

    @FindBy(xpath = "//div[@class='input-threeup-leading ']//div[@class='input-error-message']")
    private WebElement errorNameText;

    @FindBy(xpath = "//div[@class='text-input--error']//div[@class='input-error-message']")
    private WebElement errorEmailText;

    public QuestionPage(WebDriver driver) { super(driver); }

    public void isNameTextFieldButtonVisible() { nameTextFieldButton.isDisplayed(); }

    public void enterTextToNameField(final String name) {
        nameTextFieldButton.clear();
        nameTextFieldButton.sendKeys(name);
    }

    public void isEmailTextFieldButtonVisible() { emailTextFieldButton.isDisplayed(); }

    public void enterTextToEmailField(final String email) {
        emailTextFieldButton.clear();
        emailTextFieldButton.sendKeys(email);
    }

    public void isPhoneTextFieldButtonVisible() { phoneTextFieldButton.isDisplayed(); }

    public void enterTextToPhoneField(final String phone) {
        phoneTextFieldButton.clear();
        phoneTextFieldButton.sendKeys(phone);
    }

    public void isLocationTextFieldButtonVisible() { locationTextFieldButton.isDisplayed(); }

    public void enterTextToLocationField(final String location) {
        locationTextFieldButton.clear();
        locationTextFieldButton.sendKeys(location);
    }

    public void isAgeTextFieldButtonVisible() { ageTextFieldButton.isDisplayed(); }

    public void enterTextToAgeField(final String age) {
        ageTextFieldButton.clear();
        ageTextFieldButton.sendKeys(age);
    }

    public void isCheckboxAcceptSelected(){
        boolean isSelected = checkBoxSelected.isSelected();
        if(isSelected == false) {
            checkBoxSelected.click();
        }
    }

    public void clickClosePopupButton() { closePopupButton.click(); }

    public void implicitWait(long timeToWait) {
        driver.manage().timeouts().implicitlyWait(timeToWait, TimeUnit.SECONDS);
    }

    public void clickSubmitButton() { submitButton.click(); }

    public String getErrorTextHeader() { return errorQuestionText.getText(); }

    public void isquestionTextFieldVisible() { questionTextField.isDisplayed(); }

    public void enterTextToQuestionTextField(final String questionText) {
        questionTextField.clear();
        questionTextField.sendKeys(questionText);
    }

    public String getErrorNameTextHeader() { return errorNameText.getText(); }

    public String getErrorEmailTextHeader() { return errorEmailText.getText(); }

}
