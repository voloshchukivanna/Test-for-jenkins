package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CoronavirusPage extends BasePage{

    @FindBy(xpath = "//li[contains(@class,'gs-o-list-ui__item--flush gel-long-primer ')]//span[text()='Your Coronavirus Stories']")
    private WebElement yourCoronavirusStoriesButton;

    @FindBy(xpath = "//h3[text()='Your questions answered: What questions do you have?']/parent::a")
    private WebElement yourQuestionAnswered;


    public CoronavirusPage(WebDriver driver) { super(driver); }

    public void isYourCoronavirusStoriesButtonVisible() { yourCoronavirusStoriesButton.isDisplayed(); }

    public void clickYourCoronavirusStoriesButton() { yourCoronavirusStoriesButton.click(); }

    public void isYourQuestionAnsweredVisibility() { yourQuestionAnswered.isDisplayed(); }

    public WebElement askQuestionButtonReturn(){ return yourQuestionAnswered; }

    public void askQuestionButtonClick(){ yourQuestionAnswered.click(); }

}
