package pages;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class SearchPage extends BasePage{

    @FindBy(xpath = "//input[@id='search-input']")
    private WebElement searchTextField;

    @FindBy(xpath = "//button[@type='submit']")
    private WebElement searchSubmitButton;

    @FindBy(xpath = "//ul[@class='ssrcss-1020bd1-Stack e1y4nx260']//li[1]//p[@class='ssrcss-1q0x1qg-Paragraph eq5iqo00']")
    private WebElement searchResultTextFirstArticle;

    public SearchPage(WebDriver driver) { super(driver); }

    public void waitForPageLoadComplete(long timeToWait) {
        new WebDriverWait(driver, Duration.ofSeconds(timeToWait)).until(
                webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
    }

    public void isSearchTextFieldVisible() { searchTextField.isDisplayed(); }

    public void enterTextToSearchField(String articleOnNewsPage) {
        searchTextField.clear();
        searchTextField.sendKeys(articleOnNewsPage);
    }

    public void clickSearchSubmitButton() { searchSubmitButton.click(); }

    public String getTextFirstArticle() { return searchResultTextFirstArticle.getText(); }

}
