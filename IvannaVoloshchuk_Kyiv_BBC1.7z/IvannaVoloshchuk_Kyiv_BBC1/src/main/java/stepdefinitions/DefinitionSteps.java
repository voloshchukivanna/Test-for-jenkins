package stepdefinitions;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import manager.PageFactoryManager;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.*;
import static io.github.bonigarcia.wdm.WebDriverManager.chromedriver;
import static org.junit.Assert.assertEquals;

public class DefinitionSteps {

    private static final long DEFAULT_TIMEOUT = 60;

    WebDriver driver;
    HomePage homePage;
    NewsPage newsPage;
    SearchPage searchPage;
    PageFactoryManager pageFactoryManager;
    String articleOnNewsPage;
    CoronavirusPage coronavirusPage;
    QuestionPage questionPage;


    @Before
    public void testsSetUp() {
        chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        pageFactoryManager = new PageFactoryManager(driver);
        newsPage = pageFactoryManager.getNewsPage();
    }

    @And("User opens {string} page")
    public void openPage(final String url) {
        homePage = pageFactoryManager.getHomePage();
        homePage.openHomePage(url);
    }

    @And("User checks 'News' button visibility")
    public void checkNewsButtonVisibility() {
        homePage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        homePage.isNewsButtonVisible();
    }

    @When("User clicks 'News' button")
    public void clickNewsButton() {
        homePage.clickNewsButton();
    }

    @Then("User checks that the headline article is {string}")
    public void checkHeadlineArticle(String string) {
        newsPage = pageFactoryManager.getNewsPage();
        newsPage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        Assert.assertEquals(newsPage.mainArticleGetText(), string);
    }

    @Then("User checks subarticles are {string}, {string}, {string}, {string}")
    public void userChecksSubArticles(String string1, String string2, String string3, String string4) {
        String[] subArticles = {string1, string2, string3, string4};
        for(int i = 0; i < subArticles.length; i++){
           Assert.assertEquals(subArticles[i], newsPage.subArticlesGetText(i));
        }
    }

    @And("User gets headline article")
    public void getHeadlineArticle() { articleOnNewsPage = newsPage.mainArticleGetText(); }

    @And("User checks search field visibility")
    public void checkSearchVisibility() {
        newsPage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        newsPage.isSearchFieldVisible();
    }

    @And("User checks 'Search' button visibility")
    public void checkSearchButtonVisibility() {
        homePage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        homePage.isSearchButtonVisible();
    }

    @And("User click on 'Search' button")
    public void clickSearchButton() {
        homePage.clickSearchButton();
    }

    @And("User check 'Search' text field visibility")
    public void checkSearchTextFieldVisibility() {
        searchPage = pageFactoryManager.getSearchPage();
        searchPage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        searchPage.isSearchTextFieldVisible();
    }

    @And("User makes search by keyword headline article")
    public void enterKeywordToSearchField() {
        searchPage.enterTextToSearchField(articleOnNewsPage);
    }

    @And("User clicks on 'SearchSubmit' button")
    public void clickSearchSubmitButton() {
        searchPage.clickSearchSubmitButton();
    }

    @Then("User checks the name of the first headline article against a specified value")
    public void checkNameOfHeadlineArticle(){
        searchPage = pageFactoryManager.getSearchPage();
        searchPage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        assertEquals(searchPage.getTextFirstArticle(), articleOnNewsPage);
    }

    @And("User checks 'Coronavirus' visibility")
    public void checkCoronavirusTabVisibility() {
        newsPage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        newsPage.isCoronavirusButtonVisible();
    }

    @And("User clicks 'Coronavirus' button")
    public void clickCoronavirusButton() {
        newsPage.clickCoronavirusButton();
    }

    @And("User checks 'Your Coronavirus Stories' visibility")
    public void checkYourCoronavirusStoriesTabVisibility() {
        coronavirusPage = pageFactoryManager.getCoronavirusPage();
        coronavirusPage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        coronavirusPage.isYourCoronavirusStoriesButtonVisible();
    }

    @And("User clicks 'Your Coronavirus Stories' button")
    public void clickYourCoronavirusStoriesButton() {
        coronavirusPage.clickYourCoronavirusStoriesButton();
    }

    @And("User checks 'Your Question Answered' visibility")
    public void checkYourQuestionAnsweredVisibility(){ coronavirusPage.isYourQuestionAnsweredVisibility(); }

    @And("User clicks 'Your Question Answered' button")
    public void clickOnYourQuestionAnswered() {
        coronavirusPage.waitVisibilityOfElement(DEFAULT_TIMEOUT, coronavirusPage.askQuestionButtonReturn());
        coronavirusPage.scrollToElement(coronavirusPage.askQuestionButtonReturn());
        coronavirusPage.askQuestionButtonClick();
    }

    @And("User checks 'Name' visibility")
    public void checkNameTextFieldVisibility() {
        questionPage = pageFactoryManager.getQuestionPage();
        questionPage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        questionPage.isNameTextFieldButtonVisible();
    }

    @And("User enters 'Name' by keyword {string}")
    public void enterKeywordToNameField(final String name) {
        questionPage.enterTextToNameField(name);
    }

    @And("User checks 'Email' visibility")
    public void checkEmailTextFieldVisibility() {
        questionPage = pageFactoryManager.getQuestionPage();
        questionPage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        questionPage.isEmailTextFieldButtonVisible();
    }

    @And("User enters 'Email' by keyword {string}")
    public void enterKeywordToEmailField(final String email) {
        questionPage.enterTextToEmailField(email);
    }

    @And("User checks 'Phone' visibility")
    public void checkPhoneTextFieldVisibility() {
        questionPage = pageFactoryManager.getQuestionPage();
        questionPage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        questionPage.isPhoneTextFieldButtonVisible();
    }

    @And("User enters 'Phone' by keyword {string}")
    public void enterKeywordToPhoneField(final String phone) {
        questionPage.enterTextToPhoneField(phone);
    }

    @And("User checks 'Location' visibility")
    public void checkLocationTextFieldVisibility() {
        //questionPage = pageFactoryManager.getQuestionPage();
        //questionPage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        questionPage.isLocationTextFieldButtonVisible();
    }

    @And("User enters 'Location' by keyword {string}")
    public void enterKeywordToLocationField(final String location) {
        questionPage.enterTextToLocationField(location);
    }

    @And("User checks 'Age' visibility")
    public void checkAgeTextFieldVisibility() {
        questionPage = pageFactoryManager.getQuestionPage();
        questionPage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        questionPage.isAgeTextFieldButtonVisible();
    }

    @And("User enters 'Age' by keyword {string}")
    public void enterKeywordToAgeField(final String age) {
        questionPage.enterTextToAgeField(age);
    }

    @And("User clicks 'Accept' button")
    public void selectCheckboxAccept(){
        questionPage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        questionPage.isCheckboxAcceptSelected();
    }

    @And("User closes 'Sign In' popup")
    public void clickClosePopupButton() {
        questionPage.implicitWait(DEFAULT_TIMEOUT);
        questionPage.clickClosePopupButton();
    }

    @And("User clicks 'Submit' button")
    public void clickSubmitButton() {
        questionPage.clickSubmitButton();
    }

    @And("User checks error message in 'Question Text' field")
    public void checkErrorTextHeader() {
        questionPage.implicitWait(DEFAULT_TIMEOUT);
        assertEquals(questionPage.getErrorTextHeader(), "can't be blank");
    }

    @And("User checks error message in 'Name' field")
    public void checkErrorNameTextHeader() {
        questionPage.implicitWait(DEFAULT_TIMEOUT);
        assertEquals(questionPage.getErrorNameTextHeader(), "Name can't be blank");
    }

    @And("User checks error message in 'Email' field")
    public void checkErrorEmailTextHeader() {
        questionPage.implicitWait(DEFAULT_TIMEOUT);
        assertEquals(questionPage.getErrorEmailTextHeader(), "Email address can't be blank");
    }

    @And("User checks 'Question Text' visibility")
    public void checkQuestionTextFieldVisibility() {
        questionPage = pageFactoryManager.getQuestionPage();
        questionPage.waitForPageLoadComplete(DEFAULT_TIMEOUT);
        questionPage.isquestionTextFieldVisible();
    }

    @And("User enters 'Question Text' by keyword {string}")
    public void enterKeywordToQuestionTextField(final String questionText) {
        questionPage.enterTextToQuestionTextField(questionText);
    }

    @After
    public void tearDown() {
        driver.close();
    }
}
